# -*- coding: utf-8 -*-
"""
NLP project
"""
#import modules
import matplotlib.pyplot as plt
execfile("C:\Users\Malowe\Documents\UTT\Oulu\NLP\Projet\projectfiles\Project_functions.py")

#read in sententences and separate the sentence pairs
sents = open("C:\Users\Malowe\Documents\UTT\Oulu\NLP\Projet\projectfiles\sents.txt")
sents = sents.read()
sents, size = tokenize_sentences(sents)

##-----Actual calculations of Wordnet similarity  
wup_sims = [sent_similarity(sents[i][0], sents[i][1], "WUP") for i in range(size)]
path_sims = [sent_similarity(sents[i][0], sents[i][1], "PATH") for i in range(size)]

#draw a picture; blue is for wup and red for path
plt.plot(wup_sims)
plt.plot(wup_sims, 'bo')
plt.ylabel("Similarity")
plt.xlabel("Sentence pair number")
plt.plot(path_sims, 'r')
plt.plot(path_sims, 'ro')


#actual calculations of the Yago similarity
yago_path = [sent_yago(sents[i][0], sents[i][1], "wpath") for i in range(size)]
yago_graph = [sent_yago(sents[i][0], sents[i][1], "wpath_graph") for i in range(size)]

#picture
plt.plot(yago_path, label = 'corpus-based')
plt.plot(yago_path, 'bo')
plt.ylabel("Similarity")
plt.xlabel("Sentence pair number")
plt.plot(yago_graph, 'r', label = "graph-based")
plt.plot(yago_graph, 'ro')
plt.legend(loc = 'upper right')

    
#running the line below took ~8mins on test computer; dependant on internet speed
#actual calculations of the Dbpedia similarity
dbpedia = [sent_dbpedia(sents[i][0], sents[i][1]) for i in range(size)]

#picture
plt.plot(dbpedia, 'k', label = 'DBpedia similarity')
plt.plot(dbpedia, 'ko')
plt.ylabel("DbPedia Similarity")
plt.xlabel("Sentence pair number")
plt.legend(loc = 'upper right')


#W2vec embeddings
import gensim
#train the model using our own database
model = gensim.models.Word2Vec(oneDArray(sents), min_count=0) 

#actual calculations
w2vec_sim = [w2vsim(sents[i][0], sents[i][1], model) for i in range(size)]

#plotting
plt.plot(w2vec_sim)
plt.plot(w2vec_sim, 'bo')
plt.ylabel("Similarity")
plt.xlabel("Sentence pair number")


#####################
#using the google w2v model
#   https://code.google.com/archive/p/word2vec/  <-- model object
from gensim.models.keyedvectors import KeyedVectors


#this takes a while (~around 1 minute) since the model object is 3.5gb
w2v_model = KeyedVectors.load_word2vec_format("C:/Users/jaakk/Desktop/Natural Language Processing and Text Mining/Project/GoogleNews-vectors-negative300.bin", binary=True)
#w2v_model = gensim.models.Word2Vec.load("C:/Users/jaakk/Desktop/Natural Language Processing and Text Mining/Project/GoogleNews-vectors-negative300.bin")
#time.clock()-start_time

#vocab = set(w2v_model.wv.index2word)
#w2v_sim = [w2vsim(sentences[i][0], sentences[i][1], w2v_model, 300, vocab) for i in range(size)]
w2v_sim = [w2vsim(sents[i][0], sents[i][1], w2v_model) for i in range(size)]

plt.plot(w2v_sim)
plt.plot(w2v_sim, 'bo')
plt.ylabel("Similarity")
plt.xlabel("Sentence pair number")

#------- Part 4: extra - the same procedures with another set of sentence pairs
sents2 = open("C:\Users\Malowe\Documents\UTT\Oulu\NLP\Projet\projectfiles\sentsinorder.txt")
sents2 = sents2.read()
sents2, size2 = tokenize_sentences(sents2)

#note: google w2v model spells 'jewellery' in US style 'jewelry' so let's change that
sents2[3][0][4] = "jewelry"

#get the human evaluated similarities and plot them
import numpy as np

sims = open("C:\Users\Malowe\Documents\UTT\Oulu\NLP\Projet\projectfiles\sentsinordersims.txt")
sims = [float(s) for s in sims.read().split('\n')]
sims = np.divide(sims, 4) #scaling

plt.plot(sims, 'b')
plt.plot(sims, 'bo')


#calculate all the similarities under all the used concepts

#choose wu and palmer for wordnet since it worked better
wup_sims2 = [sent_similarity(sents2[i][0], sents2[i][1], "WUP") for i in range(size2)]

#yago types had no real difference; choose path
yago_path2 = [sent_yago(sents2[i][0], sents2[i][1], "wpath") for i in range(size2)]

#dbpedia   --- looks like this would around an hour; takes about a minute per sentence
dbpedia2 = [sent_dbpedia(sents2[i][0], sents2[i][1]) for i in range(size2)]

dbpedia = []
for i in range(size2):
    dbpedia.append(sent_dbpedia(sents2[i][0], sents2[i][1]))
    print(i)

#word2vec under the pretrained model
w2v_sim = [w2vsim(sents2[i][0], sents2[i][1], w2v_model) for i in range(size2)]


plt.plot(sims, 'b')
plt.plot(sims, 'bo')
plt.plot(wup_sims, 'g')
plt.plot(wup_sims, 'go')
plt.plot(path_sims,'r')
plt.plot(path_sims, 'ro')

plt.plot(sims, 'b')
plt.plot(sims, 'bo')
plt.plot(yago_path, 'c')
plt.plot(yago_path, 'co')
plt.plot(yago_graph, 'm')
plt.plot(yago_graph, 'mo')

plt.plot(sims, 'b')
plt.plot(sims, 'bo')
plt.plot(w2v_sim, 'y')
plt.plot(w2v_sim, 'yo')
plt.ylabel("Similarity")
plt.xlabel("Sentence pair number")


plt.plot(dbpedia, 'k')
plt.plot(dbpedia, 'ko')
plt.ylabel("DbPedia Similarity")
plt.xlabel("Sentence pair number")
