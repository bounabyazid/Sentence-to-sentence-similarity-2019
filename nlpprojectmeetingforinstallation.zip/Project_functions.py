#Reading the file
import nltk
from nltk.corpus import stopwords

def tokenize_sentences(sents):
    database = sents.split("\n")
    size = len(database)
    sents = [s.split(".") for s in database]
    #remove stopwords and tokenize
    stoplist = stopwords.words('english') 
    stoplist.append("12") #google list doesn't contain 12
    stoplist.append("'s") #nltk parser doesnt recognise genetive

    for i in range(size):
        for k in range(2):
            sents[i][k] = [word for word in nltk.word_tokenize(sents[i][k]) if word.lower() not in stoplist]
    
    return sents, size

#-----Part 1: WordNet Similarity
from nltk.corpus import wordnet as wn

def word_similarity(word1, word2, simMeasure):
    if(simMeasure == "WUP"):
        simmatrix = [[w1synset.wup_similarity(w2synset) for w1synset in wn.synsets(word1)] for w2synset in wn.synsets(word2)]
    elif(simMeasure == "PATH"):
        simmatrix = [[w1synset.path_similarity(w2synset) for w1synset in wn.synsets(word1)] for w2synset in wn.synsets(word2)]
    aux = [[s for s in simmatrix[i] if s != None] for i in range(len(simmatrix))]
    if any([len(a) > 0 for a in aux]):
        return(max(max(aux)))
    else:
        return(0)

def sent_similarity(sent1, sent2, simMeasure):
    maxes = [max(x) for x in [[word_similarity(s1, s2, simMeasure) for s2 in sent2] for s1 in sent1]]
    return(sum(maxes)/len(maxes))

#---- Part 2: Yago and DBPedia Similarities
#---- Yago
from sematch.semantic.similarity import YagoTypeSimilarity

#---- Yago Similarity
yago_sim = YagoTypeSimilarity()

def yago_similarity(w1, w2, method):
    similarities = [[yago_sim.yago_similarity(x, y, method) for x in yago_sim.word2yago(w1)] for y in yago_sim.word2yago(w2)]
    aux = [[s for s in similarities[i] if s != None] for i in range(len(similarities))]
    if any([len(a) > 0 for a in aux]):
        return(max(max(aux)))
    else:
        return(0)

def sent_yago(sent1, sent2, simMeasure):
    maxes = [max(x) for x in [[yago_similarity(s1, s2, simMeasure) for s2 in sent2] for s1 in sent1]]
    return(sum(maxes)/len(maxes))

#------ DBPedia
from sematch.application import Matcher
from sematch.semantic.graph import DBpediaDataTransform, Taxonomy
from sematch.semantic.similarity import ConceptSimilarity
from sematch.semantic.similarity import EntitySimilarity
from sematch.semantic.sparql import NameSPARQL


#required function definitions
matcher = Matcher(expansion = True)
name_linker = NameSPARQL()

concept = ConceptSimilarity(Taxonomy(DBpediaDataTransform()), 'models/dbpedia_type_ic.txt')
entity_sim = EntitySimilarity()

def entity_similarity(w1, w2):
    return entity_sim.similarity(w1[0], w2[0])

def concepts_links(w):
    c = [i['lod'][0] for i in w]
    return c
    
def dbpedia_similarity(w1, w2, mode):
    if mode == 'entity':
        aux = entity_similarity(w1, w2)
        return(aux)
    elif mode == 'concept':
        similarities = [[yago_sim.yago_similarity(x, y, 'wpath') for x in concepts_links(w1)] for y in concepts_links(w2)]       
        aux = [[s for s in similarities[i] if s != None] for i in range(len(similarities))]    
        if any([len(a) > 0 for a in aux]):
            return(max(max(aux)))
        else:
            return(0)
    
def sent_dbpedia(sent1, sent2):
    ent1 = [name_linker.name2entities(w)  for w in sent1 if name_linker.name2entities(w)]
    ent2 = [name_linker.name2entities(w)  for w in sent2 if name_linker.name2entities(w)]
    
    ent1 = [w  for w in ent1 if entity_similarity(w, w) == 1]
    ent2 = [w  for w in ent2 if entity_similarity(w, w) == 1]
    con1 = [matcher.type_links(w)  for w in sent1 if matcher.type_links(w)]
    con2 = [matcher.type_links(w)  for w in sent2 if matcher.type_links(w)]
    
    ent = False
    con = False
    if(len(ent1) > 0 and len(ent2) > 0):
        ent = True
        max_entity = [max(x) for x in [[dbpedia_similarity(w1, w2, 'entity') for w2 in ent2] for w1 in ent1]]
        
    if(len(con1) > 0 and len(con2) > 0):
        con = True
        max_concept = [max(x) for x in [[dbpedia_similarity(w1, w2, 'concept') for w2 in con2] for w1 in con1]]
    
    if (con and ent) :
        similarity = (sum(max_entity)/len(max_entity) + sum(max_concept)/len(max_concept))/2
    elif (con):
        similarity = sum(max_concept)/len(max_concept)
    elif(ent):
        similarity = sum(max_entity)/len(max_entity)
    else:
        similarity = 0
    return(similarity)


#---- Part 3: Word2Vec embeddings
#import Cython
#from scipy import spatial
import itertools

#to turn the sentence list into one dimension
def oneDArray(x):
    return list(itertools.chain(*x))

import numpy as np

#calculate all the pairs of similarities and average on them
def w2vsim(sent1, sent2, w2vecModel):
    maxes = [max(x) for x in [[w2vecModel.similarity(s1, s2) for s2 in sent2] for s1 in sent1]]
    return np.mean(maxes)
