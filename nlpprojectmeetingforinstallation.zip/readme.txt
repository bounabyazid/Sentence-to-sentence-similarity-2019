Files:

project.py: contains project code

sents.txt: updated file of our own sentence pair database

sentsinorder.txt: contains the sentences I found online in decreasing similarity order - source: https://www.researchgate.net/publication/238732681_Pilot_Short_Text_Semantic_Similarity_Benchmark_Data_Set_Full_Listing_and_Description

sentsinordersims.txt: the corresponding similarities for the file aboce

Presentation.ppt: I thought we could use the UniOulu template for the presentation which can be used through this

In addition, to use the google predefined model it must be downloaded from https://code.google.com/archive/p/word2vec/